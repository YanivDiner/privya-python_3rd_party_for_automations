import boto3
import stripe
import okta
from flask import app
from twilio.rest import Client
import logging
import asyncio
import okta.jwt
from okta.client import Client as OktaClient
from okta.okta_object import OktaObject
from twilio.http.http_client import TwilioHttpClient
from twilio.rest import Client
import logging
from botocore.exceptions import ClientError
from auth0.rest_async import RestClient
from auth0.authentication import GetToken
import  flask


logger = logging.getLogger(__name__)
jwt_token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik1UUWdhRkYwSUtFWDNWLXpmX2FpXyJ9.eyJnaXZlbl9uYW1lIjoieWFpci5iZW5taWNoYWVsIiwibmlja25hbWUiOiJ5YWlyLmJlbm1pY2hhZWwiLCJuYW1lIjoieWFpci5iZW5taWNoYWVsIiwicGljdHVyZSI6Imh0dHBzOi8vcy5ncmF2YXRhci5jb20vYXZhdGFyL2EwOTBjMWFiZGZmODhhZjYyYjMzZDdlYmZjYTc2MzlkP3M9NDgwJnI9cGcmZD1odHRwcyUzQSUyRiUyRmNkbi5hdXRoMC5jb20lMkZhdmF0YXJzJTJGeWEucG5nIiwidXBkYXRlZF9hdCI6IjIwMjMtMDgtMTZUMTM6NDc6NDMuNjA3WiIsImVtYWlsIjoieWFpci5iZW5taWNoYWVsQHByaXZ5YS5haSIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwiaXNzIjoiaHR0cHM6Ly9hdXRoLnByaXZ5YS5haS8iLCJhdWQiOiIxTVdJU0lKNldRR3lYbmk1SlZlenhQMmpUYkdCWmxtWiIsImlhdCI6MTY5MjUxNjY2NywiZXhwIjoxNjkyNTI3NDY3LCJzdWIiOiJhdXRoMHwwY2IwMmY1MS0wMjVmLTQyNDAtOTkxNS02NGI0YmJmYjE4YTIiLCJzaWQiOiIxWkNJTi1zTEhtUlV5RmZlNjZoSVdUeDJxSjJiVFk2QyIsIm5vbmNlIjoiYjNaUWVWTkJNelZVV21KM1VpNTBmbkJxTTJkVU9HSjZiRWw2YlVsck1scDVWRmxaVFM1RWFpMVZTdz09In0.n4hWtCwbEZCr0zymPrNH4QWYOKBNyNWJx14a0McWT-pYNkJ-rjXWJx_a7t1h_7DK3Prvpsp-ynjGatzUc5ZC8rz3zFbkT7_EnfepgSa_8i5Il2RPzLynaWbWiI4hbd7z2sa_SrzhTtdrFvfGAIQBJPEPEKsIm2ppqX0B1zsS-fCuYr3os3M6YJtaQqE4fStwHtB5RZ91rWxZYOOhUgSalfFNP5Ct2wA3ubYu2-45FGj3tKkmjBfFC9ZS3ezWuy0Kxuc444b3_ny6Q_f0ly2vTy66GKvnQjj_O4ZqcTmZtfab_IZ7VeAooQxHnkZ1IOg45vLWsuVg77vIYmnRYziFlw"
private_key = """-----BEGIN RSA PRIVATE KEY-----
MIIJKQIBAAKCAgEAwfUb0nUC0aKB3WiytFhnCIg455BYC+dR3MUGadWpIg7S6lbi
...
2tjIvH4GN9ZkIGwzxIOP61wkUGwGaIzacOTIWOvqRI0OaYr9U18Ep1trvgGR
-----END RSA PRIVATE KEY-----
"""
def decode_jwt():

    decoded_jwt = okta.jwt.JWT(private_key)
    logger.info(decoded_jwt)


def get_token():
    get_token = GetToken(
        "yair.us.auth0.com",
        "sf64df56aef",
        client_assertion_signing_key=private_key,
    )
    token = get_token.client_credentials(
        "https://my-domain.us.auth0.com/api/v2/"
    )
    logger.log()

@app.route('/register', methods=['POST'])
def register():
    if request.method == 'POST':
        # Retrieve registration data from JSON payload
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        email = data.get('email')
        # Create a new User instance and add to the database
        session = RestClient()
        new_user = User(username=username, email=email, password=password)
        session.add(new_user)
        session.commit()
        return jsonify({'message': 'Registration successful'})

