import json

import boto3
import logging

import requests
import httpx

import httpx


async def func():
  async with httpx.AsyncClient() as httpxClient:

      url = "https://api.example.com/resource"
      username = "username"
      password = "1234567"

      try:
          put_response = await httpxClient.put(url, auth=(username, password))
          get_response = await httpxClient.get(url, auth=(username, password))
      except Exception as e:
          logging.error(f"Failed to get response: {e}") 


def send_email(subject, body, sender, recipient):
    ses_client = boto3.client('ses', region_name='us-east-1')

    message = {
        'Subject': {'Data': subject},
        'Body': {'Text': {'Data': body}}
    }
    response = ses_client.send_email(
        Source=sender,
        Destination={'ToAddresses': [recipient]},
        Message=message
    )
def send_slack_message(message=None, username="moneybot"):

    if not ENABLE_SLACK or not message:
        return
    message["token"] = SLACK_API_KEY
    message["username"] = username
    url = "https://slack.com/api/chat.postMessage"
    username = "your_username" 
    password = "your_password" 
    try:
        response = requests.post(url, auth=(username, password), params=message)
        slack_response = json.loads(response.text)
        if not slack_response["ok"]:
            raise Exception(slack_response["error"])
    except Exception as e:
        logging.error(f"Failed to send Slack notification: {e}")


class ConfigurationException:
    pass


def call_bad_actor_api(request, AUTH0_PORTAL_AUDIENCE=None, AUTH0_PORTAL_M2M_CLIENT_SECRET=None,
                       AUTH0_PORTAL_M2M_CLIENT_ID=None, AUTH0_DOMAIN=None, BAD_ACTOR_API_URL=None):

    if not BAD_ACTOR_API_URL:
        raise ConfigurationException("BAD_ACTOR_API_URL unset")

    if not all(
            [
                AUTH0_DOMAIN,
                AUTH0_PORTAL_AUDIENCE,
                AUTH0_PORTAL_M2M_CLIENT_ID,
                AUTH0_PORTAL_M2M_CLIENT_SECRET,
            ]
    ):
        raise ConfigurationException("AUTH0 variable unset")

    payload = {
        "client_id": AUTH0_PORTAL_M2M_CLIENT_ID,
        "client_secret": AUTH0_PORTAL_M2M_CLIENT_SECRET,
        "audience": AUTH0_PORTAL_AUDIENCE,
        "grant_type": "client_credentials",
    }

    auth0_response = requests.post(
        url=f"https://{AUTH0_DOMAIN}/oauth/token", json=payload
    ).json()
    access_token = auth0_response["access_token"]

    headers = {
        "Authorization": f"Bearer {access_token}",
    }
    logging.info(request)
    response = requests.post(url=BAD_ACTOR_API_URL, headers=headers, json=request)
    response = response.json()
    logging.info(response)

    return BadActorResponse.parse_obj(response)