import stripe
import logging

logger = logging.getLogger(__name__)

stripe.api_key = 'sk_test_51NRw5jECZVBiajfWkTXyS0QkrFHNpmdeAHTrd8jxZsSSYyEkP9Dle60z3VP0DVyXRYquu5ywSe40oWxR8xu0IyVu00oQbmotvR'

def create_payment_intent(credit_card, currency='usd'):
    intent = stripe.PaymentIntent.create(
        payment_method_types=['card'],
        amount=1000,  # Amount in cents
        currency=currency,
        payment_method=credit_card
    )
    logger.info('Payment Intent created: %s', intent.id)
    if not intent:
        logger.error("Failed creating paymaent intent")
    return intent
