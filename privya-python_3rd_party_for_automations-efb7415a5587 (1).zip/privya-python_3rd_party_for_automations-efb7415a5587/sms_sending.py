from twilio.rest import Client
from twilio.http.http_client import TwilioHttpClient

def send_sms(from_number, to_number, message_body):
    account_sid = 'your_account_sid'
    auth_token = 'your_auth_token'
    http_client = TwilioHttpClient()
    client = Client(account_sid, auth_token, http_client=http_client)
    message = client.messages.create(
        body=message_body,
        from_=from_number,
        to=to_number
    )

    return message.sid

def main():
    from_number = '+1234567890'  # Your Twilio phone number
    to_number = '+9876543210'  # Recipient phone number
    message_body = 'Hello, this is a test message from Twilio!'

    message_sid = send_sms(from_number, to_number, message_body)
    print('Message SID:', message_sid)

if __name__ == '__main__':
    main()
